import React from "react";

export default function App() {
  return (
    <div className="bg-[#050816] text-white min-h-screen font-sans scroll-smooth">
      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/50 backdrop-blur-md border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src="/logo.jpg"
              alt="JEF Scouting"
              className="w-12 h-12 rounded-full border border-cyan-400"
            />
            <div>
              <h1 className="text-xl font-semibold tracking-wide">JEF Scouting</h1>
              <p className="text-xs text-cyan-300">Luxury Hospitality Staffing</p>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-8 text-sm">
            <a href="#about" className="hover:text-cyan-300 transition">About</a>
            <a href="#services" className="hover:text-cyan-300 transition">Services</a>
            <a href="#partners" className="hover:text-cyan-300 transition">Partners</a>
            <a href="#apply" className="hover:text-cyan-300 transition">Apply</a>
            <a href="#contact" className="hover:text-cyan-300 transition">Contact</a>
          </div>
        </div>
      </nav>

      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#020617] via-[#081229] to-black opacity-100" />

        <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
          <div className="flex justify-center mb-8">
            <img
              src="/logo.jpg"
              alt="JEF Scouting"
              className="w-40 h-40 rounded-full border-4 border-cyan-400 shadow-2xl shadow-cyan-500/20"
            />
          </div>

          <p className="uppercase tracking-[0.4em] text-cyan-300 text-sm mb-4">
            Miami Hospitality Staffing
          </p>

          <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6">
            Elite Hospitality
            <span className="block text-cyan-300">Talent Recruitment</span>
          </h1>

          <p className="max-w-3xl mx-auto text-lg md:text-xl text-gray-300 leading-relaxed mb-10">
            JEF Scouting connects luxury hotels, restaurants, lounges, and hospitality brands
            with exceptional talent across Miami.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="#contact"
              className="px-8 py-4 rounded-full bg-cyan-400 text-black font-semibold"
            >
              Hire Staff
            </a>

            <a
              href="#apply"
              className="px-8 py-4 rounded-full border border-white/20"
            >
              Apply Now
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
