# JEF Scouting Website

Luxury hospitality staffing website built with React + Vite + TailwindCSS.

## Run locally

npm install
npm run dev

## Build

npm run build
